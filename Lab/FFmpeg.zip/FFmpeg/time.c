#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define function prototypes
float get_video_duration(const char *video_path);
void extract_frame(const char *video_path, const char *time, const char *output_image);

float get_video_duration(const char *video_path) {
    // Placeholder for calling ffprobe in C
    return 10.0;  // Replace this with actual duration retrieval logic
}

void extract_frame(const char *video_path, const char *time, const char *output_image) {
    // Placeholder for calling ffmpeg in C
    printf("Extracting frame at time %s to %s\n", time, output_image);
    // Replace this with actual ffmpeg command execution
}

int main() {
    const char *video_path = "BSVRecovery.vn";
    const char *first_frame_output = "first_frame.jpg";
    const char *middle_frame_output = "middle_frame.jpg";
    const char *last_frame_output = "last_frame.jpg";

    // Get video duration
    float duration = get_video_duration(video_path);
    
    // Calculate time for frames
    char first_time[] = "00:00:01";
    char middle_time[9];
    char last_time[9];
    sprintf(middle_time, "00:00:%02d", (int)(duration / 2));
    sprintf(last_time, "00:00:%02d", (int)duration);

    // Extract frames
    extract_frame(video_path, first_time, first_frame_output);
    extract_frame(video_path, middle_time, middle_frame_output);
    extract_frame(video_path, last_time, last_frame_output);

    printf("Frames extracted:\n- First frame: %s\n- Middle frame: %s\n- Last frame: %s\n", first_frame_output, middle_frame_output, last_frame_output);

    return 0;
}
